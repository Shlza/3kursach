﻿using Microsoft.EntityFrameworkCore;

public class AppDbContext : DbContext
{
    public DbSet<Employee> Employees { get; set; }
    public DbSet<BusinessTrip> BusinessTrips { get; set; }
    public DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=localhost;Database=BusinessTripsDB;User=admin;Password=admin;TrustServerCertificate=True");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<BusinessTrip>()
            .HasKey(b => b.TripID);
        modelBuilder.Entity<Employee>()
            .HasMany(e => e.BusinessTrips)
            .WithOne(b => b.Employee)
            .HasForeignKey(b => b.EmployeeID);
        modelBuilder.Entity<User>()
            .HasKey(u => u.UserID);
    }
}
