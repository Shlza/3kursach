﻿using System.Windows;
using System.Linq;
using BusinessTrips;
using System.Windows.Controls;

namespace BusinessTrips
{
    public partial class LoginWindow : Window
    {
        private readonly AppDbContext _dbContext; // Контекст базы данных

        public LoginWindow()
        {
            InitializeComponent();
            _dbContext = new AppDbContext(); // Инициализация контекста базы данных
        }

        // Обработчик кнопки "Login"
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // Логика проверки пользователя
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            var user = _dbContext.Users.FirstOrDefault(u => u.Username == username && u.Password == password);

            if (user != null)
            {
                // Если пользователь найден, показываем MainWindow и закрываем LoginWindow
                MainWindow mainWindow = new MainWindow(); // Создаём объект основного окна
                mainWindow.Show(); // Открываем основное окно
                this.Close(); // Закрываем окно авторизации
            }
            else
            {
                MessageBox.Show("Неверные данные", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
