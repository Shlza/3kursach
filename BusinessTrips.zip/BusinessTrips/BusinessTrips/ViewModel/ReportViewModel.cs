﻿using System.Collections.Generic;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using OfficeOpenXml;
using System.Windows;
using BusinessTrips;

public partial class ReportViewModel : Window
{
    public ICommand GeneratePdfReportCommand { get; set; }
    public ICommand GenerateExcelReportCommand { get; set; }

    private readonly AppDbContext _dbContext;

    public ReportViewModel()
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        _dbContext = new AppDbContext();
        GeneratePdfReportCommand = new RelayCommand(GeneratePdfReport);
        GenerateExcelReportCommand = new RelayCommand(GenerateExcelReport);
    }

    private void GeneratePdfReport()
    {
        string filepath = "Отчет.pdf";
        var trips = _dbContext.BusinessTrips.ToList();
        // Генерация PDF
        PdfDocument document = new PdfDocument();
        PdfPage page = document.AddPage();
        XGraphics gfx = XGraphics.FromPdfPage(page);
        XFont font = new XFont("Arial", 12, XFontStyleEx.Regular);
        int y = 50;
        foreach (var trip in trips)
        {
            string tripInfo = $"ID: {trip.TripID}, Место: {trip.Destination}, Даты: {trip.StartDate} - {trip.EndDate}";
            gfx.DrawString(tripInfo, font, XBrushes.Black, new XRect(20, y, page.Width - 40, 20), XStringFormats.TopLeft);
            y += 20;
        }
        document.Save(filepath);

        MessageBox.Show($"Отчет сохранен в файл {filepath}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void GenerateExcelReport()
    {
        string filepath = "Отчет.xlsx";
        var trips = _dbContext.BusinessTrips.ToList();
        using (var package = new ExcelPackage())
        {
            var worksheet = package.Workbook.Worksheets.Add("Report");
            worksheet.Cells[1, 1].Value = "Trip ID";
            worksheet.Cells[1, 2].Value = "Destination";
            worksheet.Cells[1, 3].Value = "Start Date";
            worksheet.Cells[1, 4].Value = "End Date";
            int row = 2;
            foreach (var trip in trips)
            {
                worksheet.Cells[row, 1].Value = trip.TripID;
                worksheet.Cells[row, 2].Value = trip.Destination;
                worksheet.Cells[row, 3].Value = trip.StartDate.ToShortDateString();
                worksheet.Cells[row, 4].Value = trip.EndDate.ToShortDateString();
                row++;
            }
            package.SaveAs(new System.IO.FileInfo(filepath));

            MessageBox.Show($"Отчет сохранен в файл {filepath}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information); 
        }
    }
}
